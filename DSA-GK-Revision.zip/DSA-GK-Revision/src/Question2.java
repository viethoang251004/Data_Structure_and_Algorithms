java.util.Stack;
java.util.Queue;
java.util.LinkedList;

class Question2 {

    public static String reverse(String str)
    {
        
    }
    public static void main(String[] args) {
        
    }
}