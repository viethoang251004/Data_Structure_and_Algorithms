class MyLinkedList implements ListInterface {
    Node head;
    
    public Node getHead() {
        return head;
    }

    public void print() {
        System.out.println("[");
        for(Node n = head; n != null; n = n.getNext()) {
            System.out.print(n.getData() + ", ");
        }
        System.out.println("]");
    }


    public static void main(String[] args) {
        
    }

    @Override
    public int size() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'size'");
    }

    @Override
    public int sumEven() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'sumEven'");
    }

    @Override
    public int countKey(int k) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'countKey'");
    }
}