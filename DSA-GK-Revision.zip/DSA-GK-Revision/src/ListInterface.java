interface ListInterface {
    public int size();

    public int sumEven();

    public int countKey(int k);

}