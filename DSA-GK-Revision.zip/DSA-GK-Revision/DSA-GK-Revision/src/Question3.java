class Question3 {
    public static int sumDighits(int a)
    {
        if(a == 0)
        return 0;
        return a %10 +sumDighits(a/10);
    }
    public static int sumDigitsl(int a){
        int s =0;
        while(a!=0){
            s = s+ a%10;
            a = a/10;
        }
        return s;
    }
    public static void main(String[] args) {
        System.out.println(sumDighits(2147));
        System.out.println(sumDigitsl(2147));
    }
}