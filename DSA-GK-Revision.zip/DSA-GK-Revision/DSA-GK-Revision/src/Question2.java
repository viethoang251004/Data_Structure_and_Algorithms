import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;

class Question2 {

    public static String reverse(String str)
    {
        Stack<Character> st= new Stack<Character>();
        for( int i=0; i<str.length();++i)
            st.push(str.charAt(i));
        String res = "";
        while(!st.isEmpty())
            res += st.pop();
    return res;
    }
    public static void main(String[] args) {
       System.out.println(reverse("abcde"));
    }
}