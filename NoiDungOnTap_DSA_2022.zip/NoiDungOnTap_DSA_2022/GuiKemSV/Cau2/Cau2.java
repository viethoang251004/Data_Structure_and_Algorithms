public class Cau2 {
    public static int recur(int n, int k) {
        // code here
        return 0;
    }

    public static void main(String args[]){
		int n = 10, k =5;
        System.out.println(recur(n,k));
	}
}