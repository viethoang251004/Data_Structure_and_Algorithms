class TestCau1
{
    public static void main(String[] arg)
    {
        CharLinkedList cl = new CharLinkedList();
        cl.addFirst('A');
        cl.addAfterFirstKey('b', 'A');
        cl.addAfterFirstKey('c', 'b');
        cl.print();
        System.out.println("Largest char position: " + cl.largestCharPostition());
    }
}