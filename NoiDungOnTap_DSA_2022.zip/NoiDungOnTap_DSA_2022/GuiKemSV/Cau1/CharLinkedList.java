class CharLinkedList implements ListInterface
{
    private Node head = null;
    public CharLinkedList()
    {
        head = null;
    }
    public Node getHead()
    {
        return head;
    }
	public void addFirst(char data)
    {
        ;

    }
	public boolean addAfterFirstKey(char data, char key)
    {
        return false;
    }
	public int largestCharPostition()
    {
        
        return 0;
    }
    public void print()
    {
        Node p = head;
        while (p!= null) 
        {
            System.out.print(p.getData() + " -> ");
            p = p.getNext();
        }
        System.out.println();
    }
}