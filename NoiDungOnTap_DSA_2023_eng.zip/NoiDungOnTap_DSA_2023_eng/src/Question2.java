public class Question2 {
    public static int recur(int n, int k) {
        // code here
    }

    public static void main(String args[]){
		
	}
}