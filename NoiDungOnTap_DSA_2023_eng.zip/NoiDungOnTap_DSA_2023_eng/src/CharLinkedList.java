class CharLinkedList implements ListInterface {
    private Node head;

    public CharLinkedList() {
    }

    @Override
    public Node getHead() {
        // code here
    }

    @Override
    public void addFirst(char data) {
        // code here
    }

    @Override
    public boolean addAfterFirstKey(char data, char key) {
        // code here
    }

    @Override
    public int largestCharPostition() {
        // code here
    }
}
