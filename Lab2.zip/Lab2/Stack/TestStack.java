class TestStack
{
    public static void main(String[] args)
    {
        MyStack<Fraction> st = new MyStack<Fraction>();
        st.push(new Fraction(3,4));
        st.push(new Fraction(5,7));
        st.push(new Fraction());
        st.print();
        System.out.println(st.getPeek());
        st.pop();
        st.print();
    }
}