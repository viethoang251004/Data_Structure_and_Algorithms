import java.util.NoSuchElementException;
public class MyStack <E> implements StackInterface<E> 
{
    private Node <E> head; 
    private int numNode; 
    public MyStack()
    {
        head = null;
        numNode = 0; 
    }
    @Override
    public void push(E item)
    {
        head = new Node<E>(item, head); 
        numNode++;
    }
   
    @Override
    public E pop() throws NoSuchElementException
    {
        if(head == null)
        {
            throw new NoSuchElementException("Can't remove element from an empty list");
        } 
        else
        {
            Node<E> tmp = head;
            head = head.getNext(); 
            numNode--;
            return tmp.getData();
        } 
    }
    
    @Override

    public void print()
    {
        if(head != null)
        {
            Node<E> tmp = head;
            System.out.print("List: " + tmp.getData()); 
            tmp = tmp.getNext();
            while(tmp != null)
            {
                System.out.print(" -> " + tmp.getData()); 
                tmp = tmp.getNext();
            }
            System.out.println();
        }
        else
        {
            System.out.println("List is empty!");
        }
    }
    @Override
    public boolean isEmpty()
    {
        if(numNode == 0) 
            return true;
        return false; 
    }
    @Override
    public E getPeek() throws NoSuchElementException
    {
        if(head == null)
        {
            throw new NoSuchElementException("Can't get element from an empty list");
        } 
        else
        {
            return head.getData(); 
        }
    } 
   
    @Override
    public int size()
    {
        return numNode;
    }
    @Override
    public boolean contains(E item)
    {
        Node<E> tmp = head; 
        while(tmp != null)
        {
            if(tmp.getData().equals(item))
                return true;
            tmp = tmp.getNext();
        }
        return false; 
    }
   
}