import java.util.*;
public class Ex4 {
    public static void reverse(String s) {
        Stack<Character> str = new Stack<Character>();
        for(int i = 0 ; i < s.length(); i++) {
            char c = s.charAt(i);
            str.push(c);
        }
        while(!str.isEmpty()) {
            System.out.println(str.pop());
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap chuoi: ");
        String chuoi = sc.nextLine();
        reverse(chuoi);

    }
}
