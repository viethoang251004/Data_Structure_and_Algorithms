import java.util.*;

public class Ex3 {
    public static int P(int n) {
        if (n == 1) {
            return 3;
        } else
            return (int) (Math.pow(2, n) + n * n + P(n - 1));
    }

    public static int P1(int n) {
        Stack<Integer> p = new Stack<Integer>();
        p.push(3);
        for (int i = 2; i <= n; i++) {
            p.push((int) (Math.pow(2, i) + i * i + P1(i - 1)));
        }
        return p.peek();
    }

    public static void main(String[] args) {
        int n = 3;
        int kq1 = P(n);
        int kq = P1(n);
        System.out.println("P1(" + n + ") = " + kq);
        System.out.println("P(" + n + ") = " + kq1);
    }
}

// import java.util.*;

// public class Ex3{
//     public static int P(int n){
//        Stack<Integer> stack = new Stack<>();
//        stack.push(3);
//        for(int i =2; i<=n; i++){
//         stack.push(((int)Math.pow(2,i) + i*i));
//        }

//        int result = 0;
//        while(!stack.isEmpty()){
//         result += stack.pop();
//        }
//        return result;
//     }

//     public static int P1(int n){
//        if(n==1) return 3;
//        else return (int)(Math.pow(2,n) + n*n + P1(n-1));
//     }

//     public static void main(String[] args){
   
//         System.out.println(P(3));
//         System.out.println(P1(3));
//     }
// }