class TestQueue
{
    public static void main(String[] args)
    {
        MyQueue<Fraction> q = new MyQueue<Fraction>();
        q.enQueue(new Fraction(3,4));
        q.enQueue(new Fraction(5,8));
        q.enQueue(new Fraction());
        q.print();
        System.out.println(q.getFront());
        q.deQueue();
        q.print();
    }
}