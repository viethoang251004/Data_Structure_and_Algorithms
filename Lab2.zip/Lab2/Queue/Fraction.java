class Fraction
{
    private int num, denom;
    public Fraction()
    {
        num = denom = 1;
    }
    public Fraction(int a, int b)
    {
        num = a;
        denom = b;
    }
    public Fraction(Fraction f)
    {
        this.num = f.num;
        this.denom = f.denom;
    }
    public String toString()
    {
        return num + "/" + denom;
    }
    public boolean equals(Fraction f)
    {
        if (this.num * f.denom == this.denom * f.num)
            return true;
        return false;
    }
}